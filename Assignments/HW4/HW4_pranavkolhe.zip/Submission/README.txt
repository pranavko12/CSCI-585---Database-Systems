												HOMEWORK 4
Q1. WEKA

Linear Regression Equation:

class =

     -0.1084 * CRIM +
      0.0458 * ZN +
      2.7187 * CHAS=1 +
    -17.376  * NOX +
      3.8016 * RM +
     -1.4927 * DIS +
      0.2996 * RAD +
     -0.0118 * TAX +
     -0.9465 * PTRATIO +
      0.0093 * B +
     -0.5226 * LSTAT +
     36.3411

There are 12 terms in the equation. 11 terms represent the features and 1 represents a constant term, intercept. All of these 11 features affect the way price of the houses increase/decrease, hence these 11 features are taken in the equation.

In this equation, each feature is multiplied by a weight, that indicate the strength and direction of the relationship between each feture and housing price. 

The resultant equation represents a linear equation between these features and the housing price



Q2.KNIME

Linear Regression Equation:

number_of_rings =

	−0.8249 × sex=I +
	0.0577 × sex=M +
	−0.4583 × length +
	11.0751 × diameter +
	10.7615 × height +
	8.9754 × whole_weight +
	−19.7869 × shucked_weight +
	−10.5818 × viscera_weight +
	8.7418 × shell_weight +
	3.8946


Q3. RapidMiner

Linear Regression Equation:

number_of_rings = 

	- 11.933 * length + 
	25.766 * diameter +
 	20.358 * height + 
	2.836


